#!/bin/bash

echo ">>> Starting Struct Installation..."

# 1. Create the hidden home directory structure
STRUCT_HOME="$HOME/.struct/structures"
if [ ! -d "$STRUCT_HOME" ]; then
    echo "Creating directory: $STRUCT_HOME"
    mkdir -p "$STRUCT_HOME"
else
    echo "Directory exists: $STRUCT_HOME"
fi

# 2. Compile the application
echo "Compiling..."
# Ensure Go tracks the dependencies
if [ ! -f "go.mod" ]; then
    go mod init struct_app
    go get github.com/charmbracelet/bubbletea
    go get github.com/charmbracelet/lipgloss
    go get github.com/charmbracelet/bubbles/textinput
fi

go build -o struct .
if [ $? -ne 0 ]; then
    echo "Compilation failed! Check for errors."
    exit 1
fi
echo "Compilation successful."

# 3. Move executable to /bin
# We use /bin as requested, but we need sudo permissions.
echo "Installing 'struct' command to /bin/ (requires sudo)..."
sudo mv struct /bin/

if [ $? -eq 0 ]; then
    echo ">>> Installation Complete!"
    echo "You can now type 'struct' from anywhere in your terminal."
else
    echo "Failed to move the file. Installation incomplete."
fi